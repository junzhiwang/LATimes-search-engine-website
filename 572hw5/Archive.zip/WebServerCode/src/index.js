import SearchBar from './SearchBar';
import ReactDOM from 'react-dom';
ReactDOM.render(
  <SearchBar />,
  document.getElementById('search')
);
